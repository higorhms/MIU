package edu.miu.cs.cs544.najeeb.exam2;

public class Token {

    // You should not have new Token in your code.
    public Token() {
    }
}
