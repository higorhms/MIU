import { Component } from '@angular/core';

@Component({
  selector: 'app-benefit-fields-info',
  templateUrl: './benefit-fields-info.component.html',
  styleUrls: ['./benefit-fields-info.component.css']
})
export class BenefitFieldsInfoComponent {

}
