import { Component } from '@angular/core';

@Component({
  selector: 'app-activity-fields-info',
  templateUrl: './activity-fields-info.component.html',
  styleUrls: ['./activity-fields-info.component.css']
})
export class ActivityFieldsInfoComponent {

}
