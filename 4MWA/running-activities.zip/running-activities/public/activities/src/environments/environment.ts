export const environment = {
  BASE_URL: "http://localhost:3000/api/",
  DEFAULT_FIRST_PAGE: 1,
  PAGE_SKIPPER: 1,
  DEFAULT_AMOUNT_OF_RESULTS: 3,
  AUTH_KEY: "Auth",
  WELCOME_MESSAGE: "Welcome ",
  SUCCESS_MESSAGE: "Success ",
  BEARER: "bearer "
};
